# ==================== 1. 安装与导入 ====================
# pip install shap matplotlib pandas numpy joblib scikit-learn
import shap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
import pickle

# ==================== 2. 加载模型和数据 ====================
# 尝试加载模型（先尝试joblib，失败则用pickle）
try:
    model = joblib.load('RF.dat')
    print("模型使用 joblib 加载成功")
except:
    with open('RF.dat', 'rb') as f:
        model = pickle.load(f)
    print("模型使用 pickle 加载成功")

# 确认模型类型（应为随机森林分类器）
print("模型类型:", type(model))

# 加载特征数据（假设pre.csv是您要解释的特征文件）
X_explain = pd.read_csv('pre.csv')
print("特征数据形状:", X_explain.shape)

# 特征名称列表
feature_names = X_explain.columns.tolist()
print("特征名:", feature_names)

# ==================== 3. 创建SHAP解释器 ====================
# 随机森林是树模型，使用 TreeExplainer
explainer = shap.TreeExplainer(model)

# ==================== 4. 计算SHAP值 ====================
shap_values = explainer.shap_values(X_explain)
expected_value = explainer.expected_value

# 判断二分类还是多分类
if isinstance(shap_values, list):
    n_classes = len(shap_values)
    print(f"多分类模型，类别数: {n_classes}")
else:
    n_classes = 1  # 二分类
    print("二分类模型")

# ==================== 5. 可视化解释 ====================
# 5.1 全局特征重要性（条形图）
shap.summary_plot(shap_values, X_explain, feature_names=feature_names, plot_type="bar")
plt.tight_layout()
plt.savefig('shap_summary_bar.png', dpi=150)
plt.show()

# 5.2 全局特征分布对SHAP值的影响（点图）
shap.summary_plot(shap_values, X_explain, feature_names=feature_names)
plt.tight_layout()
plt.savefig('shap_summary_dot.png', dpi=150)
plt.show()

# 5.3 单个样本的力场图（force plot）
sample_idx = 0  # 可以选择任意样本索引
if isinstance(shap_values, list):
    # 多分类：为每个类别分别绘图
    for class_idx in range(len(shap_values)):
        print(f"绘制类别 {class_idx} 的 force plot")
        shap.force_plot(expected_value[class_idx], 
                        shap_values[class_idx][sample_idx,:], 
                        X_explain.iloc[sample_idx,:], 
                        feature_names=feature_names,
                        matplotlib=True, 
                        show=False)
        plt.savefig(f'shap_force_sample_{sample_idx}_class_{class_idx}.png', 
                    dpi=150, bbox_inches='tight')
        plt.show()
else:
    # 二分类
    shap.force_plot(expected_value, 
                    shap_values[sample_idx,:], 
                    X_explain.iloc[sample_idx,:], 
                    feature_names=feature_names,
                    matplotlib=True, 
                    show=False)
    plt.savefig(f'shap_force_sample_{sample_idx}.png', dpi=150, bbox_inches='tight')
    plt.show()

# 5.4 特征依赖图（dependence plot）
# 请替换为您感兴趣的特征名（例如 'band_gap'）
feature_of_interest = feature_names[0]  # 默认选第一个特征，您可修改
if isinstance(shap_values, list):
    # 多分类时通常分析类别0，您可指定其他类别
    target_class = 0
    shap.dependence_plot(feature_of_interest, shap_values[target_class], X_explain, 
                         feature_names=feature_names, 
                         interaction_index='auto')  # 自动选择交互特征
else:
    shap.dependence_plot(feature_of_interest, shap_values, X_explain, 
                         feature_names=feature_names, 
                         interaction_index='auto')
plt.tight_layout()
plt.savefig(f'shap_dependence_{feature_of_interest}.png', dpi=150)
plt.show()

# 5.5 决策图（decision plot）——展示多个样本的路径
if isinstance(shap_values, list):
    # 多分类，选择类别0
    shap.decision_plot(expected_value[0], shap_values[0][:50], 
                       X_explain.iloc[:50], feature_names=feature_names)
else:
    shap.decision_plot(expected_value, shap_values[:50], 
                       X_explain.iloc[:50], feature_names=feature_names)
plt.tight_layout()
plt.savefig('shap_decision.png', dpi=150)
plt.show()